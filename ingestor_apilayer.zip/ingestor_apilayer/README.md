# API REST LAYER Module


----
# API Definition
Toda la definición de API se encuentra en Clickup
API v1::REST LAYER

# Archivo .env
```
MONGODB=wwwwww //Database a usar para datos de los tenants
MONGOSTRCONNECTION=xxxxx // String de conexión con user y password ejemplo 'mongodb://user:password@yyyyy:27017'
#Colocar true si es ambiente con documentdb
DOCUMENTDB=false 

PORT=9991
#IP='xx.xxx.xx'  //IP en donde escuchara por requests. Descomentar si es diferente a 127.0.0.1
```
